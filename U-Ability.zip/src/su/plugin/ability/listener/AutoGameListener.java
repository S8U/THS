package su.plugin.ability.listener;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import su.plugin.ability.AbilityPlugin;
import su.plugin.ability.api.AbilityAPI;
import su.plugin.ability.api.category.GameState;
import su.plugin.ability.api.event.DeathEvent;
import su.plugin.ability.api.object.GamePlayer;
import su.plugin.core.common.api.ChatColor;
import su.plugin.core.common.api.Core;

public class AutoGameListener implements Listener {
	
	private AbilityAPI api = AbilityPlugin.getApi();
	
	@EventHandler
	public void onJoin(PlayerJoinEvent e) {
		if(!api.isUseAutoStart()) return;
		
		Player p = e.getPlayer();
		GamePlayer gp = api.getPlayerManager().getGamePlayer(p);

		String msg = gp.getDisplayName() + " §e님께서 접속하셨습니다.";
		
		if(!api.getGameManager().isGameStarted()) {
			String count = "( " + api.getPlayerManager().getOnlineJoinedPlayers().size() + " / " + api.getAutoStartCount()+ " )";
			msg += " " + count;

			if(api.getAutoStartCount() <= api.getPlayerManager().getOnlineJoinedPlayers().size() && api.getPlayerManager().getTeamAmount() > 1) {
				api.getGameManager().startGame(true);
			} else {
				api.getBarManager().getBossBar().setText("다른 플레이어를 기다리는 중입니다.. " + count);
				api.getBarManager().getBossBar().setProgress((float) api.getPlayerManager().getOnlineJoinedPlayers().size() / (float) api.getAutoStartCount() * 100);
			}
		} else if(!gp.isEliminate() && !gp.isWatchMode()) {
			msg = gp.getDisplayName() + " §e님께서 재접속하셨습니다.";
		} else if(gp.isWatchMode()) {
			msg = gp.getDisplayName() + " §b님께서 관전 모드로 접속하셨습니다. (관전자 수: " + api.getPlayerManager().getOnlineWatchPlayers().size() + "명)";
		}
		
		e.setJoinMessage(null);

		Core.cbc(ChatColor.YELLOW, msg);
	}
	
	@EventHandler
	public void onQuit(PlayerQuitEvent e) {
		if(!api.isUseAutoStart()) return;
		
		Player p = e.getPlayer();
		GamePlayer gp = api.getPlayerManager().getGamePlayer(p);
		String msg = gp.getDisplayName() + " §e님께서 퇴장하셨습니다.";
		
		if(api.getGameManager().isGameStarted()) {
			if(api.getGameManager().finish()) {
				api.shutdown(13);
			} else if(!api.getGameManager().getGameState().equals(GameState.END) && api.getPlayerManager().getTeamAmount() < 2) {
				api.getGameManager().stopGame();
				Core.bc("§c인원이 부족하여 게임이 중단됩니다.");
			}
		} else {
			String count = "( " + api.getPlayerManager().getOnlineJoinedPlayers().size() + " / " + api.getAutoStartCount()+ " )";
			msg += " " + count;

			if(api.getAutoStartCount() <= api.getPlayerManager().getOnlineJoinedPlayers().size() - 1 && api.getPlayerManager().getTeamAmount() > 2) {
				api.getGameManager().startGame(true);
			} else {
				api.getBarManager().getBossBar().setText("다른 플레이어를 기다리는 중입니다.. " + count);
				api.getBarManager().getBossBar().setProgress((float) api.getPlayerManager().getOnlineJoinedPlayers().size() / (float) api.getAutoStartCount() * 100);
			}
		}
		
		e.setQuitMessage(null);

		Core.cbc(ChatColor.YELLOW, msg);
	}

	@EventHandler
	public void onDeath(DeathEvent e) {
		if(!api.getGameManager().isGameStarted()) return;
		
		Bukkit.getScheduler().runTaskLater(AbilityPlugin.getInstance(), () -> {
			if(api.getGameManager().finish()) {
				api.shutdown(13);
			} else if(!api.getGameManager().getGameState().equals(GameState.END) && api.getPlayerManager().getTeamAmount() < 2) {
				api.getGameManager().stopGame();
				Core.cbc(ChatColor.RED, "§c인원 수가 부족하여 게임이 중단됩니다.");
			}
		}, 2);
	}
	
}