package su.plugin.ability.listener;

import java.util.Iterator;
import org.bukkit.BanList.Type;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerLoginEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import su.plugin.ability.AbilityPlugin;
import su.plugin.ability.api.AbilityAPI;
import su.plugin.ability.api.category.DeathReason;
import su.plugin.ability.api.category.GameState;
import su.plugin.ability.api.event.DeathEvent;
import su.plugin.ability.api.event.GameStartedEvent;
import su.plugin.ability.api.object.GamePlayer;
import su.plugin.core.bukkit.api.KCore;
import su.plugin.core.bukkit.api.event.player.PlayerDeathDamageEvent;
import su.plugin.core.bukkit.api.util.TitleUtil;
import su.plugin.core.common.api.ChatColor;
import su.plugin.core.common.api.Core;

public class SettingListener implements Listener {
	
	private AbilityAPI api = AbilityPlugin.getApi();
	
	@EventHandler
	public void onLogin(PlayerLoginEvent e) {
		Player p = e.getPlayer();
		GamePlayer gp = api.getPlayerManager().getGamePlayer(p);
		if(gp == null || gp.isEliminate()) {
			if(gp == null) {
				gp = new GamePlayer(p);
			}

			gp.setWatchMode(api.getGameManager().isAutoMode() ? api.getGameManager().isTeleportedInMap() : api.getGameManager().getGameState().getProgress() >= GameState.DRAWING.getProgress());
		} else {
			api.getTaskManager().stopEliminateTask(gp.getPlayerKey());
		}
		
		api.getPlayerManager().setGamePlayer(p, gp);
	}
	
	@EventHandler (priority = EventPriority.LOW)
	public void onJoin(PlayerJoinEvent e) {
		Player p = e.getPlayer();
		GamePlayer gp = api.getPlayerManager().getGamePlayer(p);
		
		api.getBarManager().getBossBar().addPlayers(p);
		
		gp.setOnline(true);
		gp.getKPlayer().showPlayer();
		for(PotionEffect effect : p.getActivePotionEffects()) {
			if(effect.getType().equals(PotionEffectType.INVISIBILITY) && effect.getAmplifier() == 1) {
				p.removePotionEffect(PotionEffectType.INVISIBILITY);
			}
		}

		if(api.getGameManager().isGameStarted()) {
			if(gp.isWatchMode() || gp.isEliminate()) {
				gp.toggleWatchMode(gp.isWatchMode(), false);
			}

			if(KCore.getGUIManager().hasQuickBar(p)) {
				KCore.getGUIManager().clearQuickBar(p);
			}
		} else {
			p.setGameMode(GameMode.ADVENTURE);
			
			if(api.getMapManager().getSpawn() != null) {
				KCore.teleport(p, api.getMapManager().getSpawn());
			}
		}
		
		api.getBarManager().updateSideBarAllPlayer();
	}
	
	@EventHandler (priority = EventPriority.LOWEST)
	public void onQuit(PlayerQuitEvent e) {
		Player p = e.getPlayer();
		GamePlayer gp = api.getPlayerManager().getGamePlayer(p);
		
		api.getBarManager().getBossBar().removePlayers(p);
		
		gp.setOnline(false);
		gp.setWatchMode(false);
		
		api.getBarManager().updateSideBarAllPlayer();

		if(api.getVoteManager().isGameStartVoting()) {
			api.getVoteManager().getGameStartVoteAgree().remove(gp.getPlayerKey());
			api.getVoteManager().getGameStartVoteDisagree().remove(gp.getPlayerKey());

			api.getBarManager().getWaitingQuickBar().update();
			api.getGUIManager().updateGameStartGUI();
		}

		if(api.isUseMapVote()) {
			api.getVoteManager().getMapVote().remove(gp.getPlayerKey());

			if(api.isUseWaitingQuickBar()) {
				api.getBarManager().getWaitingQuickBar().update();
			}
			api.getGUIManager().updateMapVoteGUI();
		}

		if(api.getGameManager().getGameState().getProgress() > GameState.PREPARING.getProgress() || !api.isAllowReconnect() || api.isUseReconnectTimeLimit() || gp.isEliminate() || gp.isWatchMode()) return;
		api.getTaskManager().runEliminateTask(gp.getPlayerKey());
	}
	
	@EventHandler (priority = EventPriority.LOWEST)
	public void onDeath(PlayerDeathDamageEvent e) {
		if(api.getGameManager().getGameState().getProgress() < 4 || api.isInvincibilityTime()) return;

		Player p = e.getPlayer();
		
		if(api.isKickOnDeath()) {
			p.kickPlayer("사망하여 강제 퇴장되었습니다.");
		}
		
		if(api.isBanOnDeath()) {
			Bukkit.getBanList(Type.NAME).addBan(p.getName(), "사망하여 서버에서 차단되었습니다.", null, "시스템");
		}
		
		if(!api.getGameManager().isGameStarted()) return;
		
		GamePlayer gp = api.getPlayerManager().getGamePlayer(p);
		
		gp.setLastDeathLocation(p.getLocation());
		
		if(api.isEliminateOnDeath() || (api.isEliminateOnNatureDeath() && e.getKiller() == null)) {
			gp.setEliminate(true);
		}
		
		if(!gp.isWatchMode() && !gp.isEliminate()) {
			p.setHealth(p.getHealthScale());

			p.getWorld().playSound(p.getLocation(), Sound.ENTITY_PLAYER_HURT, 1, 1);
			
			if (e.getKiller() == null) {
				if(api.isEliminateOnNatureDeath() || !api.getGameManager().isAutoMode()) {
					KCore.teleport(p, api.getGameManager().isGameStarted() ? (api.getGameManager().isTeleportedAll() ? api.getMapManager().getPlayingMap().getTPAllLocation() : api.getMapManager().getPlayingMap().getMapLocation()) : api.getMapManager().getSpawn());

					Core.cbc(ChatColor.DARK_RED, "§f" + gp.getDisplayName() + " §c님께서 자연사했습니다.");
				} else if(api.getGameManager().isAutoMode()) {
					KCore.teleport(p, api.getGameManager().isGameStarted() ? (api.getGameManager().isTeleportedAll() ? api.getMapManager().getPlayingMap().getTPAllLocation() : api.getMapManager().getPlayingMap().getMapLocation()) : api.getMapManager().getSpawn());

					Core.cbc(ChatColor.DARK_RED, "§f" + gp.getDisplayName() + " §c님께서 자연사하여 다시 부활했습니다.");
				}
				Bukkit.getPluginManager().callEvent(new DeathEvent(gp, null, DeathReason.NATURE, e, null));
			} else {
				GamePlayer kp = api.getPlayerManager().getGamePlayer(e.getKiller());
				Bukkit.getPluginManager().callEvent(new DeathEvent(gp, kp, DeathReason.PLAYER, e, null));
				
				Core.cbc(ChatColor.DARK_RED, kp.getDisplayName() + " §c님께서 §f" + gp.getDisplayName() + " §c님을 죽였습니다.");
			}

			if(!p.getWorld().isGameRule("keepInventory")) {
				Iterator<ItemStack> it = p.getInventory().iterator();

				while(it.hasNext()) {
					p.getWorld().dropItem(p.getLocation(), it.next());
				}

				p.getInventory().clear();
				p.setExp(0);

				p.updateInventory();
			}

			TitleUtil.sendTitle(p, "탈락했습니다.", 1, 1, 2);
			
			gp.toggleWatchMode(true, !gp.isWatchMode());
		}
		
		api.getBarManager().updateSideBarAllPlayer();

		e.setCancelled(true);
	}
	
	@EventHandler (priority = EventPriority.MONITOR)
	public void onRespawn(PlayerRespawnEvent e) {
		Player p = e.getPlayer();
		GamePlayer gp = api.getPlayerManager().getGamePlayer(p);
		
		if(gp.isWatchMode() && api.getGameManager().isAutoMode()) {
			e.setRespawnLocation(gp.getLastDeathLocation());
		}
	}
	
	@EventHandler
	public void onGameStarted(GameStartedEvent e) {
		Bukkit.getScheduler().runTask(AbilityPlugin.getInstance(), () -> {
			for(GamePlayer gp : api.getPlayerManager().getOnlineJoinedPlayers()) {
				gp.getPlayer().setGameMode(GameMode.SURVIVAL);
			}
		});
	}
	
}