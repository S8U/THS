package su.plugin.ability.listener.other;

import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import su.plugin.ability.api.AbilityAPI;
import su.plugin.core.common.api.player.PlayerKey;
import su.plugin.core.common.api.util.StringUtil;
import su.plugin.permission.api.PermissionAPI;
import su.plugin.permission.api.object.PermissionPlayer;
import su.plugin.prefixer.api.PrefixerAPI;
import su.plugin.prefixer.api.object.PrefixPlayer;

public class WatchPrefixListener implements Listener {

  @EventHandler(priority = EventPriority.HIGHEST)
  public void onChat(AsyncPlayerChatEvent e) {
    PlayerKey playerKey = PlayerKey.getPlayerKeyByPlatformPlayer(e.getPlayer());
    if(!AbilityAPI.getPlayerManager().getGamePlayer(playerKey).isWatchMode()) return;

    e.setFormat(makeChatFormat(playerKey, e.getFormat()));
  }

  private String makeChatFormat(PlayerKey playerKey, String format) {
    String prefix = "";
    String pPrefix = "";
    String pSuffix = "";

    if(AbilityAPI.isUsePrefixer()) {
      PrefixPlayer pfp = PrefixerAPI.getPlayerManager().getPrefixPlayer(playerKey);
      prefix = pfp.hasMainPrefix() ? StringUtil.connectString(pfp.getMainPrefixList(), "") : "";
    }

    if(AbilityAPI.isUsePermission()) {
      PermissionPlayer pp = PermissionAPI.getPlayerManager().getPermissionPlayer(playerKey);

      pPrefix = pp.getPrefix() == null ? "" : pp.getPrefix();
      pSuffix = pp.getSuffix() == null ? "" : pp.getSuffix();
    }

    return String.format(format, "§7[관전] §f" + prefix + pPrefix + "%1$s" + pSuffix, "%2$s");
  }

}
