package su.plugin.ability.listener;

import java.util.ArrayList;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.server.ServerListPingEvent;
import su.plugin.ability.AbilityPlugin;
import su.plugin.ability.api.AbilityAPI;
import su.plugin.ability.api.category.DeathReason;
import su.plugin.ability.api.category.KillType;
import su.plugin.ability.api.event.DeathEvent;
import su.plugin.ability.api.event.JoinEvent;
import su.plugin.ability.api.event.KillEvent;
import su.plugin.ability.api.object.GamePlayer;
import su.plugin.core.bukkit.api.KCore;
import su.plugin.core.bukkit.api.lib.VaultHandler;
import su.plugin.core.common.api.ChatColor;
import su.plugin.core.common.api.Core;
import su.plugin.core.common.api.player.PlayerKey;

public class PlayerListener implements Listener {

	private AbilityAPI api = AbilityPlugin.getApi();
	
	@EventHandler
	public void onPing(ServerListPingEvent e) {
		e.setMotd(api.getGameManager().isGameStarted() ? api.getPlayingMOTD() : api.getWaitingMOTD());
	}
	
	@EventHandler (priority = EventPriority.LOW)
	public void onPlayerJoin(PlayerJoinEvent e) {
		Player p = e.getPlayer();
		GamePlayer gp = api.getPlayerManager().getGamePlayer(p);
		
		if(gp.isEliminate() || gp.isWatchMode()) {
			if(gp.isReconnectEliminateMessage()) {
				gp.setReconnectEliminateMessage(false);

				gp.getKPlayer().wmsg("재접속 시간이 지나 탈락했습니다.");
				gp.getKPlayer().cmsg(ChatColor.BLUE, "관전 모드로 전환되었습니다.");
			}

			KCore.teleport(p, api.getMapManager().getProgressLocation());
		}

		JoinEvent event = new JoinEvent(gp, !gp.isEliminate(), e);
		Bukkit.getPluginManager().callEvent(event);
	}
	
	@EventHandler
	public void onPlayerDeath(PlayerDeathEvent e) {
		Player p = e.getEntity();
		
		GamePlayer gp = api.getPlayerManager().getGamePlayer(p);

		String deathMessage = null;

		if (p.getKiller() == null) {
			if(api.isEliminateOnNatureDeath() || !api.getGameManager().isAutoMode()) {
				deathMessage = gp.getDisplayName() + " §c님께서 자연사했습니다.";
			} else if(api.getGameManager().isAutoMode()) {
				deathMessage = gp.getDisplayName() + " §c님께서 자연사하여 다시 부활했습니다.";
			}
			
			Bukkit.getPluginManager().callEvent(new DeathEvent(gp, null, DeathReason.NATURE, null, e));
		} else {
			Bukkit.getPluginManager().callEvent(new DeathEvent(gp, api.getPlayerManager().getGamePlayer(p.getKiller()), DeathReason.PLAYER, null, e));
			
			GamePlayer kp = api.getPlayerManager().getGamePlayer(p.getKiller());
			deathMessage = kp.getDisplayName() + " §c님께서 §f" + gp.getDisplayName() + " §c님을 죽였습니다.";
		}

		e.setDeathMessage(null);

		Core.cbc(ChatColor.DARK_RED, deathMessage);
	}
	
	@EventHandler
	public void onPlayerQuit(PlayerQuitEvent e) {
		Player p = e.getPlayer();
		GamePlayer gp = api.getPlayerManager().getGamePlayer(p);

		if (api.getGameManager().isGameStarted() && !gp.isWatchMode() && !gp.isEliminate() && p.getHealth() < api.getQuitDeathHealth()) {
			Bukkit.getPluginManager().callEvent(new DeathEvent(gp, api.getPlayerManager().getGamePlayer(p.getKiller()), DeathReason.LOW_HEALTH, null, null));
			Core.cbc(ChatColor.RED, gp.getDisplayName() + " §c님께서 낮은 체력으로 퇴장하여 탈락 처리되었습니다.");
		}
	}

	@EventHandler
	public void onPlayerKill(DeathEvent e) {
		GamePlayer dp = e.getPlayer();
		Player p = dp.getPlayer();
		if (!api.getGameManager().isGameStarted() || p.getKiller() == null || p.getKiller().equals(p)) return;
		
		Player killer = p.getKiller();
		GamePlayer kp = api.getPlayerManager().getGamePlayer(killer);
		if (dp.isEliminate() || dp.isWatchMode() || kp.isWatchMode())return;
		
		KillType lastKillType = kp.getLastKillType();
		KillType killType = KillType.NORMAL;
		double killMoney = api.getKillMoney();
		double regularKillMoney = 0;
		
		if (lastKillType != null && !lastKillType.equals(KillType.PENTA)) {
			killType = KillType.getKillType(lastKillType.getNumber() + 1);
			regularKillMoney = killType.getKillMoney();
		}
		
		List<GamePlayer> assists = new ArrayList<>();
		if (api.isUseAssist()) {
			for (PlayerKey lpk : dp.getLastHitTimes().keySet()) {
				if (System.currentTimeMillis() - dp.getLastHitTimes().get(lpk) > api.getAssistCount() * 1000) continue;
				GamePlayer ap = api.getPlayerManager().getGamePlayer(lpk);
				assists.add(ap);
			}
		}
		
		KillEvent event = new KillEvent(killer, p, assists, api.isFirstBlood(), killMoney, regularKillMoney, api.getFirstBloodMoney(), api.getAssistMoney(), killType, e);
		Bukkit.getPluginManager().callEvent(event);
		if (event.isCancelled()) return;
		
		if (event.getKillMoney() != 0) {
			VaultHandler.giveMoney(killer, event.getKillMoney());
      Core.cmsg(killer, ChatColor.GREEN, "§a+" + event.getKillMoney() + "원 (킬)");
		}
		
		if (event.isFirstBlood()) {
			Core.bc(kp.getDisplayName() + " §c님께서 퍼스트 블러드!");

			api.setFirstBlood(false);
			if (event.getFirstBloodMoney() != 0) {
				VaultHandler.giveMoney(killer, event.getFirstBloodMoney());
				Core.cmsg(killer, ChatColor.GREEN, "§a+" + event.getFirstBloodMoney() + "원 (퍼스트 블러드)");
			}
		}
		
		if (event.getAssistMoney() != 0) {
			for (GamePlayer ap : assists) {
				VaultHandler.giveMoney(ap.getPlayerKey().getName(), event.getAssistMoney());
				if (ap.getPlayer() == null) continue;
				Core.cmsg(killer, ChatColor.GREEN, "§a+" + event.getAssistMoney() + "원 (어시스트)");
			}
		}
		
		kp.setLastKillTime(System.currentTimeMillis());
		kp.setLastKillType(event.getKillType());
		if (event.getKillType().equals(KillType.NORMAL)) return;
		
		Core.cbc(ChatColor.DARK_RED, kp.getDisplayName() + " §c님께서 §e" + event.getKillType().getText() + "!");
		
		if (event.getRegularKillMoney() != 0) {
			VaultHandler.giveMoney(killer, event.getKillType().getKillMoney());
			Core.cmsg(killer, ChatColor.GREEN, "§a+" + event.getKillMoney() + "원 (연속킬)");
		}
	}

}