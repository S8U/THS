package su.plugin.ability;

public class PermissionList {
	
	public static final String ABILITY_ADMIN = "ability.admin";
	
}