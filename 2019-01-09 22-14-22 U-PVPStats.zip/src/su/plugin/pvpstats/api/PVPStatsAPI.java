package su.plugin.pvpstats.api;

import java.util.Arrays;
import lombok.Getter;
import lombok.Setter;
import org.bukkit.Bukkit;
import su.plugin.core.bukkit.api.util.PluginUtil;
import su.plugin.core.common.api.Core;
import su.plugin.core.common.api.plugin.UPlugin;
import su.plugin.pvpstats.PVPStatsPlugin;
import su.plugin.pvpstats.api.manager.PlayerManager;
import su.plugin.pvpstats.api.manager.RankingManager;
import su.plugin.pvpstats.api.manager.RankingPrefixManager;
import su.plugin.pvpstats.api.manager.SQLManager;
import su.plugin.pvpstats.api.object.PSPlayer;

public class PVPStatsAPI {
	
	@Setter
	@Getter
	private static boolean includeNatureDeath, giveRankingPrefix;
	
	@Setter
	@Getter
	private static boolean usePrefixer;
	
	@Setter
	@Getter
	private static int assistEffectiveTime;
	
	@Getter
	private static PlayerManager playerManager;
	@Getter
	private static RankingManager rankingManager;
	@Getter
	private static RankingPrefixManager rankingPrefixManager;
	@Getter
	private static SQLManager SQLManager;
	
	public void init() {
		playerManager = new PlayerManager();
		rankingManager = new RankingManager();
		rankingPrefixManager = new RankingPrefixManager();
		SQLManager = new SQLManager();
	}
	
	public void registerPlugins() {
		if(usePrefixer = PluginUtil.existsPlugin("U-Prefixer")) {
			Core.log("U-Prefixer 플러그인과 연동되었습니다.");
		}
	}
	
	public void loadConfig(UPlugin plugin) {
		plugin.getJsonConfig().addDefault("자연사 데스 추가", true);
		plugin.getJsonConfig().addDefault("어시스트 시간(s)", 10);

		includeNatureDeath = plugin.getJsonConfig().getBoolean("자연사 데스 추가");
		assistEffectiveTime = plugin.getJsonConfig().getInt("어시스트 시간(s)");

		if(usePrefixer) {
			plugin.getJsonConfig().addDefault("순위 칭호 지급", false);
			plugin.getJsonConfig().addDefault("순위 칭호", Arrays.asList("1~10 [{pvpstats_ranking}위]"));

			giveRankingPrefix = plugin.getJsonConfig().getBoolean("순위 칭호 지급");
			for(String line : plugin.getJsonConfig().getStringList("순위 칭호")) {
				String ranking = line.substring(0, line.indexOf(" "));
				String prefix = line.substring(line.indexOf(" "));

				rankingPrefixManager.getRankingPrefixes().put(ranking, prefix);
			}
		}

		plugin.getJsonConfig().save();
		
		Core.log("설정을 불러왔습니다.");
	}
	
	public static void setKillCount(String playerKey, int count) {
		PSPlayer pp = playerManager.getPSPlayer(playerKey, true);
		
		pp.setKillCount(count);
		
		Bukkit.getScheduler().runTaskAsynchronously(PVPStatsPlugin.getInstance(), () -> pp.savePlayer());
	}
	
	public static void setDeathCount(String playerKey, int count) {
		PSPlayer pp = playerManager.getPSPlayer(playerKey, true);
		
		pp.setDeathCount(count);
		
		Bukkit.getScheduler().runTaskAsynchronously(PVPStatsPlugin.getInstance(), () -> pp.savePlayer());
	}
	
	public static void setAssistCount(String playerKey, int count) {
		PSPlayer pp = playerManager.getPSPlayer(playerKey, true);
		
		pp.setAssistCount(count);
		
		Bukkit.getScheduler().runTaskAsynchronously(PVPStatsPlugin.getInstance(), () -> pp.savePlayer());
	}
	
	public static void setKillStreak(String playerKey, int count) {
		PSPlayer pp = playerManager.getPSPlayer(playerKey, true);
		
		pp.setKillCount(count);
		
		Bukkit.getScheduler().runTaskAsynchronously(PVPStatsPlugin.getInstance(), () -> pp.savePlayer());
	}
	
	public static int getKillCount(String playerKey) {
		PSPlayer pp = playerManager.getPSPlayer(playerKey, true);
		return pp.getKillCount();
	}
	
	public static int getDeathCount(String playerKey) {
		PSPlayer pp = playerManager.getPSPlayer(playerKey, true);
		return pp.getDeathCount();
	}
	
	public static int getAssistCount(String playerKey) {
		PSPlayer pp = playerManager.getPSPlayer(playerKey, true);
		return pp.getAssistCount();
	}
	
	public static int getKillStreak(String playerKey) {
		PSPlayer pp = playerManager.getPSPlayer(playerKey, true);
		return pp.getKillStreak();
	}
	
	public static void addKillCount(String playerKey) {
		setKillCount(playerKey, getKillCount(playerKey) + 1);
	}
	
	public static void addDeathCount(String playerKey) {
		setDeathCount(playerKey, getDeathCount(playerKey) + 1);
	}
	
	public static void addAssistCount(String playerKey) {
		setAssistCount(playerKey, getAssistCount(playerKey) + 1);
	}
	
	public static void addKillStreak(String playerKey) {
		setKillStreak(playerKey, getKillStreak(playerKey) + 1);
	}
	
}