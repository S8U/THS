package su.plugin.pvpstats.api.object;

import java.util.HashMap;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.bukkit.entity.Player;
import su.plugin.core.common.api.player.PlayerKey;
import su.plugin.pvpstats.api.PVPStatsAPI;

@Getter
@RequiredArgsConstructor
public class PSPlayer {
	
	private final PlayerKey playerKey;
	
	@Setter
	private int killCount, deathCount, assistCount, winCount, quitCount, killStreak, deathStreak, winStreak, maxKillStreak, maxDeathStreak, maxWinStreak;
	
	@Setter
	private HashMap<String, Long> lastHitTimes = new HashMap<>();
	
	public Player getBukkitPlayer() {
		return (Player) playerKey.getPlatformPlayer();
	}
	
	public boolean isOnline() {
		return getBukkitPlayer() != null;
	}
	
	public void addKillCount() {
		killCount++;
	}
	
	public void addDeathCount() {
		deathCount++;
	}
	
	public void addAssistCount() {
		assistCount++;
	}

	public void addWinCount() {
		winCount++;
	}
	
	public void addKillStreak() {
		killStreak++;
	}

	public void addDeathStreak() {
		deathStreak++;
	}

	public void addWinStreak() {
		winStreak++;
	}
	
	public void setLastHitTime(String playerKey, long hitTime) {
		lastHitTimes.put(playerKey, hitTime);
	}
	
	public Long getLastHitTime(String playerKey) {
		return lastHitTimes.get(playerKey);
	}
	
	public int getScore() {
		return killCount * 2 + assistCount - deathCount * 2;
	}
	
	public void savePlayer() {
		PVPStatsAPI.getSQLManager().savePlayer(this);
	}
	
}