package su.plugin.pvpstats.api.object;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public class PSRanking {
	
	private final String playerKey, name;
	
	private final int killCount, deathCount, assistCount;
	
}