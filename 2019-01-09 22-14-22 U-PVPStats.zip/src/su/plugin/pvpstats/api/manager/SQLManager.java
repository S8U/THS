package su.plugin.pvpstats.api.manager;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import lombok.Cleanup;
import lombok.Getter;
import lombok.SneakyThrows;
import su.plugin.core.common.api.player.PlayerKey;
import su.plugin.core.common.api.sql.SQLManagerBase;
import su.plugin.core.common.api.sql.SQLTable;
import su.plugin.pvpstats.api.PVPStatsAPI;
import su.plugin.pvpstats.api.object.PSPlayer;

public class SQLManager extends SQLManagerBase {
	
	@Getter
	private SQLTable playerTable, PVPLogTable, rankingTable, rankingPrefixTable;
	
	@Override
	public void createTable() {
		playerTable = new SQLTable(this, "Player", "player_id int primary key, kill_count int, death_count int, assist_count int, win_count int, quit_count int, kill_streak int, death_streak int, win_streak int, max_kill_streak int, max_death_streak int, max_win_streak int").createTable();
		
		PVPLogTable = new SQLTable(this, "PVP_Log", "killer_id int, dead_id int, type varchar(255), time bigint").createTable();

		rankingTable = new SQLTable(this, "Player_Ranking", "ranking int primary key, player_id int, kill_count int, death_count int, assist_count int, win_count int, quit_count int, point int").createTable();
		if(PVPStatsAPI.isGiveRankingPrefix()) {
			rankingPrefixTable = new SQLTable(this, "Player_Ranking_Prefix", "player_id int, prefix varchar(255)").createTable();
		}
	}
	
	//
	
	public void savePlayer(PSPlayer pp) {
		playerTable.insertDuplicate(pp.getPlayerKey(), pp.getKillCount(), pp.getDeathCount(), pp.getAssistCount(), pp.getQuitCount(), pp.getKillStreak(), pp.getDeathCount(), pp.getWinStreak(), pp.getMaxKillStreak(), pp.getMaxDeathStreak(), pp.getMaxWinStreak());
	}
	
	//
	
	@SneakyThrows(SQLException.class)
	public PSPlayer getPlayer(PlayerKey playerKey) {
		@Cleanup PreparedStatement state = playerTable.select("*", "where player_id = " + playerKey);
		@Cleanup ResultSet result = state.executeQuery();

		if(!result.next()) return null;

		PSPlayer pp = new PSPlayer(playerKey);

		pp.setKillCount(result.getInt("kill_count"));
		pp.setDeathCount(result.getInt("death_count"));
		pp.setAssistCount(result.getInt("assist_count"));
		pp.setWinCount(result.getInt("win_count"));
		pp.setQuitCount(result.getByte("quit_count"));

		pp.setKillStreak(result.getInt("kill_streak"));
		pp.setDeathStreak(result.getInt("death_streak"));
		pp.setWinStreak(result.getInt("win_streak"));

		pp.setMaxKillStreak(result.getInt("max_kill_streak"));
		pp.setMaxDeathStreak(result.getInt("max_death_streak"));
		pp.setMaxWinStreak(result.getInt("max_win_streak"));

		return pp;
	}
	
	@SneakyThrows(SQLException.class)
	public List<PSPlayer> getAllPlayer() {
		List<PSPlayer> l = new ArrayList<>();

		@Cleanup PreparedStatement state = playerTable.select("*");
		@Cleanup ResultSet result = state.executeQuery();

		while(result.next()) {
			PSPlayer pp = new PSPlayer(PlayerKey.getDummy(result.getInt("player_id")));

			pp.setKillCount(result.getInt("kill_count"));
			pp.setDeathCount(result.getInt("death_count"));
			pp.setAssistCount(result.getInt("assist_count"));
			pp.setWinCount(result.getInt("win_count"));
			pp.setQuitCount(result.getByte("quit_count"));

			pp.setKillStreak(result.getInt("kill_streak"));
			pp.setDeathStreak(result.getInt("death_streak"));
			pp.setWinStreak(result.getInt("win_streak"));

			pp.setMaxKillStreak(result.getInt("max_kill_streak"));
			pp.setMaxDeathStreak(result.getInt("max_death_streak"));
			pp.setMaxWinStreak(result.getInt("max_win_streak"));

			l.add(pp);
		}

		return l;
	}
	
	//

	public void uploadRanking() {
		rankingTable.delete();

		for(int i = 0; i < PVPStatsAPI.getRankingManager().getRanking().size(); i++) {
			PSPlayer psp = PVPStatsAPI.getRankingManager().getRanking().get(i);

			rankingTable.insertDuplicate(i + 1, psp.getPlayerKey(), psp.getKillCount(), psp.getDeathCount(), psp.getAssistCount(), psp.getWinCount(), psp.getQuitCount());
		}
	}

	//
	
	public void writePVPLog(PlayerKey killerPlayerKey, PlayerKey deadPlayerKey, String type) {
		PVPLogTable.insert(null, killerPlayerKey, deadPlayerKey, type, System.currentTimeMillis());
	}
	
}