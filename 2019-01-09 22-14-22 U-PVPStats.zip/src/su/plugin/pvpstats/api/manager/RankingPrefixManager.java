package su.plugin.pvpstats.api.manager;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import lombok.Getter;
import lombok.Setter;
import shadowuni.plugin.prefixer.api.PrefixerAPI;
import shadowuni.plugin.pvpstats.api.PVPStatsAPI;
import su.plugin.core.common.api.util.NumberUtil;
import su.plugin.prefixer.api.PrefixerAPI;
import su.plugin.pvpstats.api.PVPStatsAPI;

public class RankingPrefixManager {
	
	@Setter
	@Getter
	private LinkedHashMap<String, String> rankingPrefixes = new LinkedHashMap<>();
	
	public void giveRankingPrefixToAll() {
		List<String> t = new ArrayList<>();
		
		for(String str : rankingPrefixes.keySet()) {
			List<Integer> ranking = NumberUtil.getIntegers(str);
			
			String prefix = rankingPrefixes.get(str);
			
			for(String pk : PVPStatsAPI.getRedisManager().getRanking(ranking.get(0), ranking.get(ranking.size() - 1))) {
				if(t.contains(pk) || PrefixerAPI.hasPrefix(pk, prefix)) continue;
				PrefixerAPI.addPrefix(pk, prefix);
				
				String tempPrefix = PVPStatsAPI.getRedisManager().getPrefixTemp(pk);
				if(tempPrefix != null && !tempPrefix.equals(prefix)) {
					PrefixerAPI.deletePrefix(pk, tempPrefix);
					PVPStatsAPI.getRedisManager().deletePrefixTemp(pk);
				}
				
				PVPStatsAPI.getRedisManager().addPrefixTemp(pk, prefix);
				t.add(pk);
			}
		}
		
		Map<String, String> m = PVPStatsAPI.getRedisManager().getAllPrefixTemp();
		for(String p : m.keySet()) {
			if(t.contains(p)) continue;
			
			PVPStatsAPI.getRedisManager().deletePrefixTemp(p);
		}
	}
	
}