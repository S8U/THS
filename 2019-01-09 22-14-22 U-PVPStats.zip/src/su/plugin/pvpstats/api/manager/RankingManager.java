package su.plugin.pvpstats.api.manager;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Timer;
import lombok.Getter;
import lombok.Setter;
import su.plugin.pvpstats.api.object.PSPlayer;

@Setter
@Getter
public class RankingManager {

  private Calendar updateTime;

  private Timer updateTimer;

  private List<byte[]> rankingUpdateTimes = new ArrayList<>();

  private List<PSPlayer> ranking;



}
