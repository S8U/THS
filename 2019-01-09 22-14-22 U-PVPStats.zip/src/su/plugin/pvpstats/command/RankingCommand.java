package su.plugin.pvpstats.command;

import java.util.Set;

import org.bukkit.command.CommandSender;

import shadowuni.plugin.library.LibraryPlugin;
import shadowuni.plugin.library.api.Library;
import shadowuni.plugin.library.api.command.CommandListener;
import shadowuni.plugin.library.api.command.SubCommandHandler;
import shadowuni.plugin.library.api.command.UnRegisterableCommand;
import shadowuni.plugin.library.api.util.NumberUtil;
import shadowuni.plugin.pvpstats.PVPStatsPlugin;
import shadowuni.plugin.pvpstats.PermissionList;
import shadowuni.plugin.pvpstats.api.PVPStatsAPI;
import su.plugin.core.common.api.command.SubCommandHandler;
import su.plugin.core.common.api.command.UCommandListener;
import su.plugin.core.common.api.command.UnregisterableCommandListener;
import su.plugin.core.common.api.util.NumberUtil;
import su.plugin.pvpstats.PVPStatsPlugin;
import su.plugin.pvpstats.api.PVPStatsAPI;

public class RankingCommand implements UCommandListener, UnregisterableCommandListener {
	
	private PVPStatsAPI api = PVPStatsPlugin.getApi();
	
	@SubCommandHandler(
			parent = "전적",
			name = "순위",
			aliases = {"ㅅㅇ", "랭킹", "ㄹㅋ", "ranking", "top"},
			additional = "(<페이지>)",
			permission = PermissionList.KILLSTATE_RANKING,
			usage = "순위를 확인합니다."
			)
	public void ranking(CommandSender sender, String[] args) {
		int page = args.length < 1 ? 1 : NumberUtil.getInteger(args[0]);
		if(page == -1) {
			lib.wmsg(sender, "페이지는 정수만 입력 가능합니다.");
			return;
		}
		
		int maxPage = (int) (Math.ceil(api.getRedisManager().getAllScoreCount() / 7) + 1);
		if(page > maxPage) {
			lib.wmsg(sender, "페이지는 1부터 " + maxPage + "까지의 정수만 입력 가능합니다.");
			return;
		}
		
		Set<String> s = api.getRedisManager().getRanking((page - 1) * 7 + 1, page * 7);
		
		lib.nmsg(sender, "§c[ 순위 ( " + page + " / " + maxPage + " ) ]");
		int i = 0;
		for(String pk : s) {
			int num = (page -  1) * 7 + i;
			
			lib.nmsg(sender, "§d" + (num + 1) + " ) §f" + pk);
			
			i++;
		}
	}
	
}