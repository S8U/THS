package su.plugin.pvpstats.command;

import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import shadowuni.plugin.library.LibraryPlugin;
import shadowuni.plugin.library.api.Library;
import shadowuni.plugin.library.api.command.Command;
import shadowuni.plugin.library.api.command.SubCommandHandler;
import shadowuni.plugin.pvpstats.PVPStatsPlugin;
import shadowuni.plugin.pvpstats.PermissionList;
import shadowuni.plugin.pvpstats.api.PVPStatsAPI;
import shadowuni.plugin.pvpstats.api.object.PSPlayer;
import su.plugin.core.common.api.command.Command;
import su.plugin.core.common.api.command.SubCommandHandler;
import su.plugin.core.common.api.command.UCommandListener;
import su.plugin.pvpstats.PVPStatsPlugin;
import su.plugin.pvpstats.api.PVPStatsAPI;
import su.plugin.pvpstats.api.object.PSPlayer;

public class UserCommand implements UCommandListener {
	
	private PVPStatsAPI api = PVPStatsPlugin.getApi();
	
	@SubCommandHandler(
			parent = "전적",
			name = "정보",
			aliases = {"ㅈㅂ", "info"},
			additional = "(<플레이어>)",
			permission = PermissionList.KILLSTATE_INFO,
			usage = "전적을 확인합니다."
			)
	public void info(CommandSender sender, String[] args, Command cmd) {
		if(args.length < 1 && !(sender instanceof Player)) {
			cmd.sendUsage(sender, true);
			return;
		}
		
		String player = args.length < 1 ? sender.getName() : args[0];
		
		String playerKey = lib.getPlayerKey(player, true);
		if(playerKey == null) {
			lib.wmsg(sender, "존재하지 않는 플레이어입니다.");
			return;
		}
		
		PSPlayer pp = api.getPlayerManager().getPSPlayer(playerKey);
		
		lib.nmsg(sender, "§c[ " + (args.length < 1 ? "내" : args[0] + "님의") + " 정보 ]");
		lib.nmsg(sender, "§c킬: §f" + pp.getKillCount());
		lib.nmsg(sender, "§c데스: §f" + pp.getDeathCount());
		lib.nmsg(sender, "§c어시스트: §f" + pp.getAssistCount());
		lib.nmsg(sender, "§c현재 연속 킬: §f" + pp.getKillStreak());
	}
	
}