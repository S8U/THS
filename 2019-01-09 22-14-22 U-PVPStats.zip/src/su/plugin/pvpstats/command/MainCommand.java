package su.plugin.pvpstats.command;

import org.bukkit.command.CommandSender;
import shadowuni.plugin.library.api.Library;
import shadowuni.plugin.library.api.command.Command;
import shadowuni.plugin.library.api.command.CommandHandler;
import shadowuni.plugin.library.api.command.SubCommand;
import su.plugin.core.common.api.command.Command;
import su.plugin.core.common.api.command.CommandHandler;
import su.plugin.core.common.api.command.SubCommand;
import su.plugin.core.common.api.command.UCommandListener;

public class MainCommand implements UCommandListener {
	
	@CommandHandler(
			name = "전적",
			aliases = { "pvpstats", "ps" },
			usage = "칭호 명령어를 확인합니다."
			)
	public void pm(CommandSender sender, String[] args, Command command) {
		Library.nmsg(sender, "§c§l[ U-PVPStats ]");
		for(SubCommand sc : Library.getCommandManager().getSubCommands("전적", 1)) {
			if(sc.getPermission() == null || !sender.hasPermission(sc.getPermission())) continue;
			sc.sendUsageIfHasPermission(sender, false);
		}
	}
	
}