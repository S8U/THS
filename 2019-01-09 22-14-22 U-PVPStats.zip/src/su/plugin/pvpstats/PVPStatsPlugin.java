package su.plugin.pvpstats;

import lombok.Getter;
import su.plugin.core.bukkit.api.KCore;
import su.plugin.core.bukkit.api.plugin.UKPlugin;
import su.plugin.core.common.api.ChatColor;
import su.plugin.pvpstats.api.PVPStatsAPI;
import su.plugin.pvpstats.listener.placeholder.PlaceHolderHook;

public class PVPStatsPlugin extends UKPlugin {
	
	@Getter
	private static PVPStatsPlugin instance;
	
	@Getter
	private static PVPStatsAPI api = new PVPStatsAPI();
	
	@Override
	public void onUEnable() {
		instance = this;
		setPrefix("§c[ U-PVPStats ]");
		setColor(ChatColor.RED);

		api.init();
		
		if(!api.getSQLManager().connect(this)) {
			wlog("MySQL에 연결할 수 없어 비활성화됩니다.");
			disable();
			return;
		}
		
		registerListeners();
		registerCommands();
		if(KCore.isUsePlaceholderAPI()) {
			new PlaceHolderHook().hook();
		}
		registerPermissions();
		
		api.registerPlugins();
		
		api.loadConfig(this);
		
		api.getPlayerManager().registerAllPlayers();
	}
	
	@Override
	public void onUDisable() {
		api.getSQLManager().close();
	}
	
}