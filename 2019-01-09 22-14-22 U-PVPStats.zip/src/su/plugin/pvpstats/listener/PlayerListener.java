package su.plugin.pvpstats.listener;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import shadowuni.plugin.library.LibraryPlugin;
import shadowuni.plugin.library.api.Library;
import shadowuni.plugin.pvpstats.PVPStatsPlugin;
import shadowuni.plugin.pvpstats.api.PVPStatsAPI;
import shadowuni.plugin.pvpstats.api.object.PSPlayer;
import su.plugin.pvpstats.PVPStatsPlugin;
import su.plugin.pvpstats.api.PVPStatsAPI;
import su.plugin.pvpstats.api.object.PSPlayer;

public class PlayerListener implements Listener {
	
	private PVPStatsAPI api = PVPStatsPlugin.getApi();
	
	@EventHandler
	public void onJoin(PlayerJoinEvent e) {
		api.getPlayerManager().registerPlayer(e.getPlayer());
	}
	
	@EventHandler
	public void onQuit(PlayerQuitEvent e) {
		api.getPlayerManager().removePSPlayer(lib.getPlayerKey(e.getPlayer()));
	}
	
	//
	
	@EventHandler
	public void onDeath(PlayerDeathEvent e) {
		Player p = e.getEntity();
		if(p.getKiller() == null && !api.isIncludeNatureDeath()) return;
		
		PSPlayer pp = api.getPlayerManager().getPSPlayer(lib.getPlayerKey(p));
		pp.addDeathCount();
		pp.setKillStreak(0);
		pp.addDeathStreak();
		
		PSPlayer kp = api.getPlayerManager().getPSPlayer(lib.getPlayerKey(p.getKiller()));
		kp.addKillCount();
		kp.addKillStreak();
		kp.setDeathStreak(0);
		
		for(String pk : pp.getLastHitTimes().keySet()) {
			if(System.currentTimeMillis() - pp.getLastHitTime(pk) > PVPStatsAPI.getAssistEffectiveTime() * 1000) continue;
			
			PVPStatsAPI.addAssistCount(pk);
		}
		
		Bukkit.getScheduler().runTaskAsynchronously(PVPStatsPlugin.getInstance(), () -> {
			pp.savePlayer();
			kp.savePlayer();
			
			api.getSQLManager().writePVPLog(kp.getPlayerKey(), pp.getPlayerKey(), kp.getKillStreak(), pp.getDeathStreak());
			
			if(!api.isGiveRankingPrefix()) return;
			api.getRankingPrefixManager().giveRankingPrefixToAll();
		});
	}
	
	@EventHandler(priority = EventPriority.HIGH)
	public void onHit(EntityDamageByEntityEvent e) {
		if(!(e.getEntity() instanceof Player)) return;
		
		Player p = e.getDamager() instanceof Projectile && ((Projectile) e.getDamager()).getShooter() instanceof Player ? (Player) ((Projectile) e.getDamager()).getShooter() : (Player) e.getDamager();
		if(p == null) return;
		
		Player tp = (Player) e.getEntity();
		PSPlayer tpp = api.getPlayerManager().getPSPlayer(lib.getPlayerKey(tp.getName()));
		
		tpp.setLastHitTime(lib.getPlayerKey(p), System.currentTimeMillis());
	}
	
}