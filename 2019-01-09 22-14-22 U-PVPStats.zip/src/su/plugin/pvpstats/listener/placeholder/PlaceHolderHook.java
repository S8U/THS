package su.plugin.pvpstats.listener.placeholder;

import me.clip.placeholderapi.external.EZPlaceholderHook;
import org.bukkit.entity.Player;
import su.plugin.core.common.api.player.PlayerKey;
import su.plugin.pvpstats.PVPStatsPlugin;
import su.plugin.pvpstats.api.object.PSPlayer;

public class PlaceHolderHook extends EZPlaceholderHook {

  public PlaceHolderHook() {
    super(PVPStatsPlugin.getInstance(), "U-PVPStats");
  }

  @Override
  public String onPlaceholderRequest(Player p, String identifier) {
    String lower = identifier.toLowerCase();

    PSPlayer psp = new PSPlayer(PlayerKey.getPlayerKeyByPlatformPlayer(p));
    if(psp == null) return null;

    int i = -1;
    if(lower.equals("pvpstats_kill_count")) {
      i = psp.getKillCount();
    } else if(lower.equals("pvpstats_death_count")) {
      i = psp.getDeathCount();
    } else if(lower.equals("pvpstats_assist_count")) {
      i = psp.getAssistCount();
    } else if(lower.equals("pvpstats_win_count")) {
      i = psp.getWinCount();
    } else if(lower.equals("pvpstats_quit_count")) {
      i = psp.getQuitCount();
    } else if(lower.equals("pvpstats_kill_streak")) {
      i = psp.getKillStreak();
    } else if(lower.equals("pvpstats_death_streak")) {
      i = psp.getDeathStreak();
    } else if(lower.equals("pvpstats_win_streak")) {
      i = psp.getWinStreak();
    } else if(lower.equals("pvpstats_max_kill_streak")) {
      i = psp.getMaxKillStreak();
    } else if(lower.equals("pvpstats_max_death_streak")) {
      i = psp.getMaxDeathStreak();
    } else if(lower.equals("pvpstats_max_win_streak")) {
      i = psp.getMaxWinStreak();
    }

    return i + "";
  }

}
